#!/bin/bash
wine Balsamiq-Mockups-3.exe
